import setuptools
from package import Package


setuptools.setup(
        name="numpy_dummy",
        version="6.6.6",
        author="Rasp Berry",
        packages=setuptools.find_packages(),
        include_package_data=True,
        cmdclass={
            "package": Package
            }
        )

